import 'package:flutter/material.dart';
import 'package:tayo_app/config/routes/app_routes.dart';
import 'package:tayo_app/core/utils/strings.dart';

class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  var formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          SizedBox(
            width: double.infinity,
            height: double.infinity,
            child: Image.asset(
              'assets/images/loginBackground.png',
              fit: BoxFit.cover,
            ),
          ),
          SingleChildScrollView(
            child: Center(
              child: Column(
                //mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(
                    height: 15,
                  ),
                  const Text(
                    AppStrings.appTitleEn,
                    //textAlign: TextAlign.right,
                    style: TextStyle(
                        fontSize: 96,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  const Text(
                    AppStrings.appTitleAr,
                    //textAlign: TextAlign.right,
                    style: TextStyle(
                        fontSize: 96,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    AppStrings.gm3Aktr,
                    //textAlign: TextAlign.right,
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  const SizedBox(
                    height: 35,
                  ),
                  const Text(
                    AppStrings.login,
                    //textAlign: TextAlign.right,
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 23),
                    child: Form(
                        key: formKey,
                        child: Column(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(50)),
                              child: TextFormField(
                                cursorColor: Colors.white,
                                decoration: InputDecoration(
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: const BorderSide(color: Colors.red),
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  enabledBorder: UnderlineInputBorder(
                                    borderSide: const BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  border: InputBorder.none,
                                  floatingLabelBehavior:
                                      FloatingLabelBehavior.never,
                                  labelText: AppStrings.id,
                                  filled: true,
                                  fillColor: Colors.white,
                                  labelStyle: const TextStyle(fontSize: 18),
                                ),
                                onChanged: (text) {
                                  //password = text;
                                },
                                validator: (text) {
                                  if (text == null || text.trim().isEmpty) {
                                    return AppStrings.enterId;
                                  } else {
                                    return null;
                                  }
                                },
                              ),
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            TextFormField(
                              cursorColor: Colors.white,
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                focusedBorder: OutlineInputBorder(
                                  borderSide:
                                      const BorderSide(color: Colors.red),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                enabledBorder: UnderlineInputBorder(
                                  borderSide:
                                      const BorderSide(color: Colors.grey),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                floatingLabelBehavior:
                                    FloatingLabelBehavior.never,
                                labelText: AppStrings.password,
                                filled: true,
                                fillColor: Colors.white,
                                labelStyle: const TextStyle(fontSize: 18),
                              ),
                              onChanged: (text) {
                                //password = text;
                              },
                              validator: (text) {
                                if (text == null || text.trim().isEmpty) {
                                  return AppStrings.enterPassword;
                                }
                                if (text.length < 8) {
                                  return AppStrings.inCorrectFormatPassword;
                                } else {
                                  return null;
                                }
                              },
                            ),
                          ],
                        )),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  ElevatedButton(
                      style: ButtonStyle(
                          shape: MaterialStatePropertyAll(
                              RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15))),
                          backgroundColor: const MaterialStatePropertyAll(
                              Color(0xFFFF0080))),
                      onPressed: () {
                        validateCheck();
                        setState(() {});
                      },
                      child: const Text(
                        AppStrings.login,
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      )),
                  const SizedBox(
                    height: 8,
                  ),
                  InkWell(
                    onTap: () {
                      /// the password is forgotten
                    },
                    child: const Text(
                      AppStrings.passwordForgotten,
                      //textAlign: TextAlign.right,
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.pushNamed(
                          context, AppRoutes.registerScreenRouteName);
                    },
                    child: const Text(
                      AppStrings.register,
                      //textAlign: TextAlign.right,
                      style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Future<void> validateCheck() async {
    if (formKey.currentState?.validate() == true) {}
  }
}
