/// CrashLytics to know any errors in my app
/// FlutterError.onError