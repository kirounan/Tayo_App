class AppRoutes {
  static const String homeScreenRouteName = 'homeScreen' ;
  static const String loginScreenRouteName = 'loginScreen' ;
  static const String registerScreenRouteName = 'registerScreen' ;
  static const String splash2ScreenRouteName = 'splash2Screen' ;

}