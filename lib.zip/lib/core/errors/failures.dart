abstract class Failures {}

class ServerFailures extends Failures{}
class LocalFailures extends Failures{}
class NetworkFailures extends Failures{}