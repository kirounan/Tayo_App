class AppConsts {
  static const String baseUrl = '';
}