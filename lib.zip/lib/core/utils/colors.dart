import 'package:flutter/material.dart';

class AppColors {
  static Color redColor = Colors.red ;
}