import 'package:flutter/material.dart';

/// google fonts

class AppStyles {
  /*TextStyle textPoppins25 = GoogleFonts.poppins (
    fontSize : 25 ,
  );
   */
}